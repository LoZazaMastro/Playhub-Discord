/*
 * Vesktop, a desktop app aiming to give you a snappier Discord Experience
 * Copyright (c) 2025 Vendicated and Vencord contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import type arRpcPlugin from "@vencord/types/plugins/arRPC.web";
import { Logger } from "@vencord/types/utils";
import { findLazy, onceReady } from "@vencord/types/webpack";
import { FluxDispatcher, InviteActions, StreamerModeStore } from "@vencord/types/webpack/common";
import { IpcCommands } from "shared/IpcEvents";

import { onIpcCommand } from "./ipcCommands";
import { Settings } from "./settings";

const logger = new Logger("VesktopRPC", "#5865f2");

const arRPC = Vencord.Plugins.plugins["WebRichPresence (arRPC)"] as typeof arRpcPlugin;

let userDisabledStreamerMode = false;

onIpcCommand(IpcCommands.RPC_ACTIVITY, async jsonData => {
    if (!Settings.store.arRPC) return;

    await onceReady;

    const data = JSON.parse(jsonData);

    if (data.socketId === "STREAMERMODE" && StreamerModeStore.autoToggle) {
        const value = data.activity?.application_id === "STREAMERMODE";

        if (!value) {
            userDisabledStreamerMode = false;
        } else if (userDisabledStreamerMode) {
            return;
        }

        FluxDispatcher.dispatch({
            type: "STREAMER_MODE_UPDATE",
            key: "enabled",
            value,
            isAuto: true
        });

        return;
    }

    arRPC.handleEvent(new MessageEvent("message", { data: jsonData }));
});

onceReady.then(() => {
    FluxDispatcher.subscribe("STREAMER_MODE_UPDATE", e => {
        if (!e.isAuto && !e.value) {
            userDisabledStreamerMode = true;
        }
    });
});

onIpcCommand(IpcCommands.RPC_INVITE, async code => {
    const { invite } = await InviteActions.resolveInvite(code, "Desktop Modal");
    if (!invite) return false;

    VesktopNative.win.focus();

    FluxDispatcher.dispatch({
        type: "INVITE_MODAL_OPEN",
        invite,
        code,
        context: "APP"
    });

    return true;
});

const { DEEP_LINK } = findLazy(m => m.DEEP_LINK?.handler);

onIpcCommand(IpcCommands.RPC_DEEP_LINK, async data => {
    logger.debug("Opening deep link:", data);
    try {
        DEEP_LINK.handler({ args: data });
        return true;
    } catch (err) {
        logger.error("Failed to open deep link:", err);
        return false;
    }
});
